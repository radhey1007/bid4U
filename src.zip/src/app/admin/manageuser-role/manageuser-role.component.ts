import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-manageuser-role',
  templateUrl: './manageuser-role.component.html',
  styleUrls: ['./manageuser-role.component.css']
})
export class ManageuserRoleComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
