import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-changepassword-a',
  templateUrl: './changepassword-a.component.html',
  styleUrls: ['./changepassword-a.component.css']
})
export class ChangepasswordAComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
