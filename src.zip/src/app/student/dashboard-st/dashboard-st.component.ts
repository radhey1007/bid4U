import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dashboard-st',
  templateUrl: './dashboard-st.component.html',
  styleUrls: ['./dashboard-st.component.css']
})
export class DashboardStComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
