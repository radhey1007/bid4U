
export const environment = {
  production: false,
   apiurl:'http://ec2-18-218-16-167.us-east-2.compute.amazonaws.com/TLA/api/',
  loggeduser:[],
  token:[],
 // apiurl:'http://localhost:54462/api/'
};


