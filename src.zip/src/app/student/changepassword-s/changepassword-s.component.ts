import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-changepassword-s',
  templateUrl: './changepassword-s.component.html',
  styleUrls: ['./changepassword-s.component.css']
})
export class ChangepasswordSComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
