export const environment = {
  production: false,
  apiurl: "http://103.133.215.247/TLA/api/",
  docUrl: "http://103.133.215.247/TLA/",
  loggeduser: [],
  token: []
  //apiurl:'http://localhost:54462/api/'
};
