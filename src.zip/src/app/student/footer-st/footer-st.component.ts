import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-footer-st',
  templateUrl: './footer-st.component.html',
  styleUrls: ['./footer-st.component.css']
})
export class FooterStComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
