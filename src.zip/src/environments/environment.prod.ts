export const environment = {
  production: true,
  apiurl: "http://103.133.215.247/TLA/api/",
  docUrl: "http://103.133.215.247/TLA/",
  loggeduser: [],
  token: []
};
