export class user {
  public UserName: string;
  public Email: string;
  public Password: string;
  public FullName: string;
}
