import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-footer-ad',
  templateUrl: './footer-ad.component.html',
  styleUrls: ['./footer-ad.component.css']
})
export class FooterAdComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
