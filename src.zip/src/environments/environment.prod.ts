export const environment = {
  production: true,
  apiurl:'http://ec2-18-218-16-167.us-east-2.compute.amazonaws.com/TLA/api/',
  loggeduser:[],
  token:[]
};
   