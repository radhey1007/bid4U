import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sidebar-st',
  templateUrl: './sidebar-st.component.html',
  styleUrls: ['./sidebar-st.component.css']
})
export class SidebarStComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
